package otodikhazi.person;

public enum Gender {
  MALE,
  FEMALE;
};